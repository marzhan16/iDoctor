package com.se.idoctor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IDoctorApplicationTests {

    @Test
    void contextLoads() {
    }

}
